---
name: presentation
description: Open Terminal에서 편집 가능한 PPTX를 만들거나 수정하고 검증하여 파일 카드로 전달합니다.
---
# PPT 제작

공통 AGENTS.md의 workspace 명령으로 사용자별 새 작업 폴더를 만듭니다. 스크립트·예제는 core 루트 기준입니다. 하네스 폴더는 수정하지 않습니다.

1. 내용·대상·장수·사용자 제공 PPTX를 확인합니다. 원본 템플릿이 필요한 경우 첨부 전달 도구로 원본을 가져옵니다. 없는 경로나 파일을 추측하지 않습니다.
2. 명명된 웹사이트 스타일 또는 DESIGN.md 요청이면 catalog에서 design-md, 이어 ppt-design-adapter의 entrypoint를 읽습니다. 디자인 요청이 없으면 외부 파일을 다운로드할 필요가 없습니다.
3. `scripts/doctor.py` 결과를 참고하여 실제 설치된 글꼴·라이브러리를 선택합니다. 글꼴 설치는 공통 서버 설정이므로 누락 시 사용자에게 필요한 설치를 안내합니다.
4. 내용에 맞는 슬라이드를 설계하고 작업 폴더에 `ppt-theme.json`, `slides.json`을 작성합니다. 예시 구조는 `examples/theme.json`, `examples/slides.json`입니다.
5. 기본 제목/본문/카드 레이아웃은 `python3 <root>/scripts/build_pptx.py --theme <theme.json> --slides <slides.json> --output <새 파일.pptx>`로 생성할 수 있습니다. 표·차트·기존 템플릿 편집·특수 레이아웃은 설치된 python-pptx/PptxGenJS로 별도 스크립트를 작성합니다. 기본 빌더가 임의의 디자인을 완벽하게 재현하는 것은 아닙니다.
6. `python3 <root>/scripts/validate_pptx.py <파일.pptx>`를 실행합니다. 구조/경계 검사만으로 시각 검수가 끝났다고 하지 않습니다. LibreOffice 및 렌더링 도구가 있으면 별도 임시 폴더/프로필에서 렌더링하고 사용 가능한 이미지 도구로 잘림·겹침·한글을 확인합니다. 없으면 시각 검증 미실시를 알립니다.
7. 실제 존재하는 최종 PPTX를 Terminal의 `display_file`로 반환합니다. 성공한 파일 메타데이터를 확인합니다. 경로만 답변에 적는 것으로 카드 반환을 대신하지 않습니다. 카드 도구가 없거나 실패하면 이를 명시합니다.

본문은 일반적으로 18–24pt, 제목 30–40pt에서 시작하고 정보가 많으면 슬라이드를 나눕니다. 날짜·수치·학교 정보는 요청이나 자료를 근거로 쓰며 임의로 만들지 않습니다. 로고는 요청된 경우에만 사용합니다. 한글 글꼴을 제목·본문·표·차트에도 적용합니다. PPTX는 글꼴 파일을 자동 포함하지 않으므로 열람 PC에 해당 글꼴이 없으면 대체될 수 있음을 필요할 때 알립니다.
